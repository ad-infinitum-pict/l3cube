
#include <iostream>
#include <stdlib.h>
#include <math.h>

using namespace std;
void fillUp(int birthdays [], int size)
{
    for (int i = 0; i < size; i++)
    {
        birthdays[i] = rand() % 365 + 1;
    }
}



void radexp(int noexp, int ppl){

    const int trials(noexp);
    double total=0,total1=0;
    int count, birthdays[ppl];
    srand(time(NULL));
    int k,count1;
    for (k = 0; k < trials; k++)
    {
        fillUp(birthdays, ppl);
        count=0;
        for (int i = 0; i < ppl; i++)
        {
            count1=1;
            for (int j = i + 1; j < ppl; j++)
            {

                if (birthdays[i] == birthdays[j])
                {
                    count1 += 1;
                }
            }
            if(count<count1)
                count=count1;
        }
        total = total + (count/(float)ppl);

    }
    total1 = total / noexp;
    cout <<" the probability is " << total1 << endl;
}

void actop(int ppl)
{
    double result=1.0;
    for(int i=1;i<=ppl;i++)
    {
        result = result * (double(365 - i +1)/365);
    }
    result = 1.0 - result;
    cout<<"\nActual Probability :"<<result<<endl;
}

int main()
{
    int noexp,ppl=0;
    cout<<"\nEnter number of experiments:";
    cin>>noexp;
    cout<<"Enter number of people:";
    cin>>ppl;
    radexp(noexp,ppl);
    actop(ppl);
    return 0;
}

