#include <string>
#include <iostream>
#include <pcap.h>
using namespace std;
 
#ifndef PCAP_ERRBUF_SIZE
#define PCAP_ERRBUF_SIZE 256
#endif

void preth(int fst, int end,const u_char *data1,int flag1)
{
	if(flag1==0){
	printf("%.2x",data1[fst]);
        int v1=fst+1;
        while(v1< end)
        {
        	printf(":%.2x",data1[v1] );
        	v1++;
        }
    }
    else
    {
    	printf("%d",data1[fst]);
        int v1=fst+1;
        while(v1< end)
        {
        	printf(".%d",data1[v1] );
        	v1++;
        }
    }
}

void callarp(const u_char *data)
{
	printf("\n\n---ARP header details---");
	int htype=(data[14]<<8) | data[15];
	if(htype == 1)
		printf("\nHardware Type: Ethernate(%d)",htype);
	if(data[16]==0x08 && data[17] == 0x00 )
		printf("\nProtocol Type: IP");
	printf("\nHardware size: %d",data[18]);
	printf("\nProtocol size: %d",data[19]);
	int opcode=(data[20]<<8) | data[21];
	if(opcode==1)
	{
		printf("\nOpcode: Request packet");
	}
	if(opcode==2)
		printf("\nOpcode: Response packet");
	printf("\nSender MAC addrs:");
	preth(22,28,data,0);
	printf("\nSource IP addrs:");
	preth(28,32,data,1);
	printf("\nDestination MAC addrs:");
	preth(32,38,data,0);
	printf("\nDestination IP addrs:");
	preth(38,42,data,1);

}


void callip(const u_char *data)
{
	printf("\n\n---IP header details---");

    int temp = (data[14]>>4) & 0xf;
    printf("\nVersion: %d",temp);
    int hlen = data[14] & 0x0f;
    printf("\nHeader length: %d bytes",hlen*4 );

    int tlength=(data[16]<<8) | data[17];
        	printf("\nTotal length: %d",tlength);
        	int idf=(data[18]<<8) | data[19];
        	printf("\nIdentification: %d (0x%x)",idf,idf);
        	printf("\nTime to Live: %d",data[22]);
        	if(data[23]==0x06)
        	{
        		printf("\nTransport Protocol: TCP");
        	}
        	int cnt1;
 			printf("\nSource IP: ");
 			preth(26,30,data,1);
        	
 			printf("\nDestination IP: ");
 			preth(30,34,data,1);
        	
 			if(data[23]==0x06)
        	{
        		printf("\n\n---TCP header details---");
        		int srcprt=(data[34]<<8) | data[35];
        		printf("\nSource Port: %d ",srcprt);
        		int dstprt=(data[36]<<8) | data[37];
        		printf("\nDestination Port: %d ",dstprt);
        		int seq=(data[38]<<24) | (data[39]<<16) | (data[40]<<8) | data[41];
        		printf("\nSequence Number: %x",seq);
        		int ack=(data[42]<<24) | (data[43]<<16) | (data[44]<<8) | data[45];
        		printf("\nAcknowledgement Number: %x",ack);
			}
}

int idtype(const u_char *data1)
{
	if(data1[12]==0x08 && data1[13]== 0x06)
	{
		printf("\tARP");
		return 1;
	}
	if(data1[12]==0x08 && data1[13] == 0x00 )
	{
		printf("\tIP");
		return 0;
	}
}


int main(int argc, char *argv[])
{

 
    string file;

    cout << "Enter the name of File you want to summarize:(tcp-ecn-sample.pcap or arp-storm.pcap)\n";

    cin >> file;
 
    char errbuff[PCAP_ERRBUF_SIZE];
 
    
    pcap_t * pcap = pcap_open_offline(file.c_str(), errbuff);
 
    
    struct pcap_pkthdr *header;
 
    const u_char *data;
 
    u_int packetCount = 0;
 
    long time1 = 0;
 
    int srcip[4], destip[4];
 
    while (int returnValue = pcap_next_ex(pcap, &header, &data) >= 0)
    {
        printf("Packet # %i\n", ++packetCount);
 
        printf("Packet size: %ld bytes\n", header->len);        

        if (header->len != header->caplen)
            printf("Warning! Capture size different than packet size: %ld bytes\n", header->len);
 
        // Show Epoch Time
        printf("\nEpoch Time: %ld:%ld seconds", header->ts.tv_sec, header->ts.tv_usec);
        
        if(packetCount == 1)
        {
        	time1 = header->ts.tv_usec;
        }
        long timeT = header->ts.tv_usec;
        printf("\nTime : %ld",(timeT - time1));
 		
        int typpe1= pcap_datalink(pcap);

        if(typpe1==1)
        {
        	printf("\n\n---Ethernate header details---");
        }


        printf(" \nSource addrs:  ");
        preth(6,12,data,0);

        printf("\nDestination addrs:   ");
        preth(0,6,data,0);

        printf("\nProtocol Type:");
        int dltype=idtype(data);

        
        if(dltype==0)
        {
        	callip(data);
        }
        if(dltype == 1)
        {
        	callarp(data);
        	
        }

        printf("\n\n");
    }
}
