//============================================================================
// Name        : weblog.cpp
// Author      : Ad-infinitum
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {

	ifstream file;
	ofstream o1;
	file.open("/home/abhishek/l3cube/weblog/weblog.txt");
	o1.open("/home/abhishek/l3cube/weblog/logdb.txt",ios_base::app);
	string str;


	while(!file.eof())
	{
		string s1,s2,s3,s4,s5,s6;
		getline(file,str);
		//cout<<"\n"<<str;
		size_t pos1 = str.find("- -");
		s1 = str.substr(0,pos1);
		cout<<"\n\tClient IP: "<<s1;

		//size_t pos2 = str.find("]");
		s2 = str.substr(str.find("[")+1,(str.find("-0700")-str.find("[")-1));
		cout<<"\tDate & Time: "<<s2;
		string sub1= str.substr(str.find('"')+1,(str.size()-str.find('"')));
		s3 = sub1.substr(0,sub1.find('"'));
		cout<<"\tRequest LIne: "<<s3;
		string stacz= sub1.substr(sub1.find('"')+1);
		s4= stacz.substr(0,stacz.find('"'));
		cout<<"\n\t Status code and size:"<<s4;
		string surl= stacz.substr(stacz.find('"')+1);
		s5 = surl.substr(0,surl.find('"'));
		cout<<"\tReferring URL: "<<s5;
		string sbrw= surl.substr(surl.find('"')+3);
		s6 = sbrw.substr(0,sbrw.find('"'));
		cout<<"\tBrowser details: "<<s6;
		o1<<s1<<"\t"<<s2<<"\t"<<s3<<"\t"<<s4<<"\t"<<s5<<"\t"<<s6<<"\n";
	}
	o1.close();
	file.close();
	return 0;
}
