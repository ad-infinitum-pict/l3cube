import java.sql.*;
import java.util.Scanner;

public class logdb{
	public static void main(String[] args){
		Connection conn=null;
		Statement stmt=null;
		try{
		Class.forName("com.mysql.jdbc.Driver");
		conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "abhi", "abhi");
		System.out.println("Connection created");
		stmt=conn.createStatement();
		System.out.println("Statement created");
		boolean r1 = stmt.execute("create database if not exists logdb");
		
		boolean r3 = stmt.execute("use logdb");
		boolean r2 = stmt.execute("create table if not exists log (client_ip varchar(255),data_n_time varchar(255),status_line varchar(255),code_n_size varchar(50),url varchar(255),Browser_details varchar(255))");
		
		//String  filepath = "'/home'/abhishek'/workspace'/weblogdb'/src'/logdb.txt";
		int r4 = stmt.executeUpdate("LOAD DATA LOCAL INFILE '/home/abhishek/workspace/weblogdb/src/logdb.txt' INTO TABLE log");
		System.out.println("\nTotal no of entries in log:"+r4);
		ResultSet rs= stmt.executeQuery("select count(*) as no_of_request from log where status_line like '%GET%'");
		while(rs.next())
		{
			
			System.out.println("\nNo of Request lines:"+rs.getString(1));
			
		}
		
		ResultSet rs1= stmt.executeQuery("select count(*) as no_of_response from log where status_line like '%POST%'");
		while(rs1.next())
		{
			
			System.out.println("\nNo of Response lines:"+rs1.getString(1));
			
		}
		
		int cip = stmt.executeUpdate("CREATE VIEW count_view as select client_ip,count(*) from log group by client_ip;");
		ResultSet rs8= stmt.executeQuery("select count(*) from count_view;");
		while(rs8.next())
		{
			
			System.out.println("\nNo of unique IP's  :"+rs8.getString(1));
			
		} 
		boolean rmv5 = stmt.execute("drop view count_view");
		
		//System.out.println("Enter name of");
		
		
		/*Scanner in = new Scanner(System.in);
		System.out.println("Enter URL to get no of hits:");
		String s= in.nextLine();
		*/
		System.out.println("\n------------Information of twibuzz.com-------------");
		ResultSet rs3= stmt.executeQuery("select count(*) from log where url like '%twibuzz%'");
		while(rs3.next())
		{
			
			System.out.println("\nNo of hits of www.twibuzz.com  :"+rs3.getString(1));
			
		}
		int reqt = stmt.executeUpdate("create view req1_url as select url,status_line,count(*) as count1 from log group by status_line having status_line like '%GET www.twibuzz.com%'");
		ResultSet rs4= stmt.executeQuery("select sum(count1) as sum1 from req1_url;");
		while(rs4.next())
		{
			
			System.out.println("\nNO of request for twibuzz.com :"+rs4.getString(1));
			
		} 
		boolean rmv1 = stmt.execute("drop view req1_url");
		
		int rest = stmt.executeUpdate("create view res1_url as select url,status_line,count(*) as count1 from log group by status_line having status_line like '%POST www.twibuzz.com%'");
		ResultSet rs5= stmt.executeQuery("select sum(count1) as sum1 from res1_url;");
		while(rs5.next())
		{
			
			System.out.println("\nNO of response for twibuzz.com :"+rs5.getString(1));
			
		} 
		boolean rmv2 = stmt.execute("drop view res1_url");
		
		ResultSet rs9= stmt.executeQuery("select count(*) from log where data_n_time like '%14/May/2009%' and url like '%twibuzz%'");
		while(rs9.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 14/May/2009 :"+rs9.getString(1));
			
		} 
		
		ResultSet rs10= stmt.executeQuery("select count(*) from log where data_n_time like '%15/May/2009%' and url like '%twibuzz%'");
		while(rs10.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 15/May/2009 :"+rs10.getString(1));
			
		} 
		
		ResultSet rs11= stmt.executeQuery("select count(*) from log where data_n_time like '%16/May/2009%' and url like '%twibuzz%'");
		while(rs11.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 16/May/2009 :"+rs11.getString(1));
			
		}
		
		ResultSet rs12= stmt.executeQuery("select count(*) from log where data_n_time like '%17/May/2009%' and url like '%twibuzz%'");
		while(rs12.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 17/May/2009 :"+rs12.getString(1));
			
		}
		
		ResultSet rs13= stmt.executeQuery("select count(*) from log where data_n_time like '%18/May/2009%' and url like '%twibuzz%'");
		while(rs13.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 18/May/2009 :"+rs13.getString(1));
			
		}
		
		ResultSet rs14= stmt.executeQuery("select count(*) from log where data_n_time like '%19/May/2009%' and url like '%twibuzz%'");
		while(rs14.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 19/May/2009 :"+rs14.getString(1));
			
		}
		
		System.out.println("\n\n------------Information of kinneryandrajan.com-------------");
		
		ResultSet rs2= stmt.executeQuery("select count(*) from log where url like '%kinneryandrajan%'");
		while(rs2.next())
		{
			
			System.out.print("\nNo of hits of www.kinneryandrajan.com  :"+rs2.getString(1));
			System.out.println("\n");
			
		} 
		
		
		int reqk = stmt.executeUpdate("create view req2_url as select url,status_line,count(*) as count1 from log group by status_line having status_line like '%GET www.kinneryandrajan.com%'");
		ResultSet rs6= stmt.executeQuery("select sum(count1) as sum1 from req2_url;");
		while(rs6.next())
		{
			
			System.out.println("\nNo of request for kinneryandrajan.com  :"+rs6.getString(1));
			
		} 
		boolean rmv3 = stmt.execute("drop view req2_url");
		
		int resk = stmt.executeUpdate("create view res2_url as select url,status_line,count(*) as count1 from log group by status_line having status_line like '%POST www.kinneryandrajan.com%'");
		ResultSet rs7= stmt.executeQuery("select sum(count1) as sum1 from res2_url;");
		while(rs7.next())
		{
			
			System.out.println("\nNo of response for kinneryandrajan.com  :"+rs7.getString(1));
			
		} 
		boolean rmv4 = stmt.execute("drop view res2_url");
		
		ResultSet rs15= stmt.executeQuery("select count(*) from log where data_n_time like '%14/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs15.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 14/May/2009 :"+rs15.getString(1));
			
		} 
		
		ResultSet rs16= stmt.executeQuery("select count(*) from log where data_n_time like '%15/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs16.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 15/May/2009 :"+rs16.getString(1));
			
		} 
		
		ResultSet rs17= stmt.executeQuery("select count(*) from log where data_n_time like '%16/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs17.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 16/May/2009 :"+rs17.getString(1));
			
		}
		
		ResultSet rs18= stmt.executeQuery("select count(*) from log where data_n_time like '%17/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs18.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 17/May/2009 :"+rs18.getString(1));
			
		}
		
		ResultSet rs19= stmt.executeQuery("select count(*) from log where data_n_time like '%18/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs19.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 18/May/2009 :"+rs19.getString(1));
			
		}
		
		ResultSet rs20= stmt.executeQuery("select count(*) from log where data_n_time like '%19/May/2009%' and url like '%kinneryandrajan.com%'");
		while(rs20.next())
		{
			
			System.out.print("\nNO of hits for twibuzz.com on 19/May/2009 :"+rs20.getString(1));
			
		}
		
		//boolean rmdb = stmt.execute("drop database if exists logdb");
		boolean rmtbl = stmt.execute("delete from log");
		}catch( SQLException se){
			se.printStackTrace();	
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally{
			try
			{
			if(stmt !=null)
			{
				stmt.close();
			}
		}catch(SQLException se2){
			
		}
			try
			{
				if(conn != null)
				{
					conn.close();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		System.out.println("\nGoodbye");
	}
}
